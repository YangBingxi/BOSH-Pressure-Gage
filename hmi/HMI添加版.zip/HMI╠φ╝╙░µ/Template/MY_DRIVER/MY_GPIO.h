#ifndef __MY_GPIO_H
#define __MY_GPIO_H
#include "sys.h"


void my_gpio_init(void);
void my_exit_init(void);
#endif
