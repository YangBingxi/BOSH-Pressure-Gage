#ifndef MY_PWM_H
#define MY_PWM_H

void TIM1_PWM_Init(unsigned int arr,unsigned int psc);
void PWM_Set(char chx,int data);
#endif

