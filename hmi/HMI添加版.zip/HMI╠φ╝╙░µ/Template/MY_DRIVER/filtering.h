#ifndef  Filter_H
#define Filter_H

float M_F(float*ptr,int num);
#endif
