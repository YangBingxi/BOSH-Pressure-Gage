#ifndef PID_H
#define PID_H
int Pid_control_1(float next_point1);
int Pid_control_2(float next_point2);
#endif
