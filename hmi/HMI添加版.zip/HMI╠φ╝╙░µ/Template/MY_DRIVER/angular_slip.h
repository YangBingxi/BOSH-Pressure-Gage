#ifndef angular_slip_h
#define angular_slip_h


void angular_slip_init(void);
float get_angular_slip(void);
float get_angular_slip_aver(int time);
#endif
